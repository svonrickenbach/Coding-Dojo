var childheight = 40;
function displayIfChildIsAbleToRideTheRollerCoaster() {
if (childheight >= 52) {
console.log ("Get on that ride, kiddo!");
}
else {
console.log ("Sorry kiddo. Maybe next year.");    
}    
}
displayIfChildIsAbleToRideTheRollerCoaster()