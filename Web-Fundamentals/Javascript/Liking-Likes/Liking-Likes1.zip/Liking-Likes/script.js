var count = 9;
var countelement = document.querySelector(".count");

console.log(countelement);

;function likeButton() { 
    count++
    countelement.innerText = count + " like(s)";
    console.log(count);

}

var count2 = 12;
var countelement2 = document.querySelector(".count2");

console.log(countelement2);

;function likeButton2() { 
    count2++
    countelement2.innerText = count2 + " like(s)";
    console.log(count);

}

var count3 = 9;
var countelement3 = document.querySelector(".count3");

console.log(countelement3);

;function likeButton3() { 
    count3++
    countelement3.innerText = count3 + " like(s)";
    console.log(count);

}