from tokenize import Name


print("Hello World")
name = "Noelle"
print("Hello", name, "!") 
print("Hello " + name + "!")
name = 42
print("Hello", name, "!")
print("Hello " + str(name) + "!")

fave_food1 = "sushi"
fave_food2 = "pizza"
print("I love to eat {} and {}.".format(fave_food1, fave_food2))
print(f"I love to eat {fave_food1} and {fave_food2}.")